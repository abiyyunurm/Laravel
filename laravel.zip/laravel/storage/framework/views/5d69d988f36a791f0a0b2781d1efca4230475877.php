<?php $__env->startSection('title','Daftar Mahasiswa'); ?>
<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="row">
        <div class="col-6">
            <h1 class="mt-3">Daftar Mahasiswa</h1>
            <a href="students/create" class="btn btn-primary my-3">Tambah Data Mahasiswa</a>
            <?php if(session('status')): ?>
                <div class="alert alert-sucess">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <ul class="list-group">
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <?php echo e($studen->nama); ?>

                    <a href="/students/show/<?php echo e($studen->id); ?>" class="badge badge-info">detail</a>
                </li>
            </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cobaLaravel\resources\views/students/index.blade.php ENDPATH**/ ?>